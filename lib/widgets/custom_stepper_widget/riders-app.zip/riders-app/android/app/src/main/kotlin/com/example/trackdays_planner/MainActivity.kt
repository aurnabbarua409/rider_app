package com.example.trackdays_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

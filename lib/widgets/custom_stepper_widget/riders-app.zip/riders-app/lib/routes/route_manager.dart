import 'package:get/get.dart';
import 'package:trackdays_planner/screens/all_events_event_details_screen/all_events_event_details_screen.dart';

import '../screens/auth_screens/login_screen/login_screen.dart';
import '../screens/auth_screens/register_screen/register_screen.dart';
import '../screens/cart_screen/cart_screen.dart';
import '../screens/events_screen/events_screen.dart';
import '../screens/home_screen/home_screen.dart';
import '../screens/language_selection_screen/language_selection_screen.dart';
import '../screens/notifications_screen/notifications_screen.dart';
import '../screens/onboarding_screen/onboarding_screen.dart';
import '../screens/product_details_screen/product_details_screen.dart';
import '../screens/product_screen/product_screen.dart';
import '../screens/purchased_events_event_details_screen/purchased_events_event_details_screen.dart';
import '../screens/splash_screen/splash_screen.dart';
import 'app_routes.dart';

class RouteManager {
  RouteManager._();

  static const initial = AppRoutes.splashScreen;

  static List<GetPage> getPages() {
    return [
      // General Screens
      GetPage(
        name: AppRoutes.splashScreen,
        page: () => SplashScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.languageSelectionScreen,
        page: () => LanguageSelectionScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.onboardingScreen,
        page: () => OnboardingScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.registerScreen,
        page: () => RegisterScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.loginScreen,
        page: () => LoginScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.homeScreen,
        page: () => HomeScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.productScreen,
        page: () => ProductScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.productDetailScreen,
        page: () => ProductDetailScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.cartScreen,
        page: () => CartScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.notificationsScreen,
        page: () => NotificationsScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.eventsScreen,
        page: () => EventsScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.allEventsEventDetailsScreen,
        page: () => AllEventsEventDetailsScreen(),
        // binding: GeneralBindings(),
      ),
      GetPage(
        name: AppRoutes.purchasedEventsEventDetailsScreen,
        page: () => PurchasedEventsEventDetailsScreen(),
        // binding: GeneralBindings(),
      ),
    ];
  }
}

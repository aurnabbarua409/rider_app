class StepperData {
  final String title;
  final String subtitle;

  const StepperData({
    required this.title,
    required this.subtitle,
  });
}

class AppStrings {
  AppStrings._();

  static const String appName = "Trackdays Planner";
  static const String fontFamilyName = "Inter";

  // Language Selection Screen
  static const String selectLanguage = "Please select your desired language.";
  static const String english = "English";
  static const String spanish = "Spanish";
  static const String french = "French";
  static const String german = "German";
  static const String dutch = "Dutch";
  static const String submit = "Submit";

  // Onboarding Screen
  static const String next = "Next";
  static const String skip = "Skip";
  static const String welcome = "Welcome to Trackdays Planner!";
  static const String onboardingDescription =
      "Get ready to explore upcoming track events, shop premium gear, and manage your bookings.";
  static const String explore = "Explore Without Login";
  static const String register = "Register";
  static const String login = "Login";

  // Registration Screen
  static const String createAccount = "Create Your Account";
  static const String registerDescription =
      "Register now to book track days, order gear, and track your progress.";
  static const String fullName = "Full Name";
  static const String email = "Email Address";
  static const String password = "Password";
  static const String confirmPassword = "Confirm Password";
  static const String byContinuing = "By continuing, you agree to the ";
  static const String termsAndConditions = "Terms & Conditions";
  static const String and = " and ";
  static const String privacyPolicy = "Privacy Policy";
  static const String create = "Create Account";
  static const String alreadyHaveAccount = "Already have an account? ";

  // Login Screen
  static const String welcomeBack = "Welcome Back!";
  static const String loginDescription =
      "Log in to manage your events, shop gear, and track your progress.";
  static const String dontHaveAccount = "Don’t have an account? ";

  // Home Screen
  static const String yourPurchasedEvents = "Your Purchased Events";
  static const String upcomingTrackDays = "Upcoming Track Days";
  static const String seeAll = "See All";
  static const String viewDetails = "View Details";
  static const String fillForm = "Fill Form";
  static const String yourGallery = "Your Gallery";
  static const String viewGallery = "View Gallery";
  static const String yourOrders = "Your Orders";
  static const String sendOrder = "Send order to:";
  static const String items = "Items";
  static const String viewOrderDetails = "View Order Details";
  static const String gearUp = "Gear Up for the Track";

  // Product Screen
  static const String bestSelling = "Best-Selling Gear";
  static const String shopTopProducts = "Shop Top Products";
  static const String loadMore = "Load More";

  // Product Details Screen
  static const String detaile = "Detaile";
  static const String addToCart = "Add To Cart";

  // Cart Screen
  static const String cartItems = "Cart Items";
  static const String checkout = "Checkout";
  static const String continueText = "Continue";
  static const String totalPrice = "Total Price";

  // Notifications Screen
  static const String notifications = "Notifications";
  static const String all = "All";
  static const String newText = "New";
  static const String unread = "Unread";
  static const String eventDetails = "Event Details";

  // Event Screen
  static const String gearupForTheseEvents = "Gear Up for These Events";
  static const String allEvents = "All Events";
  static const String purchasedEvents = "Purchased Events";
  static const String browseAllEvents = "Browse All Events";
  static const String yourRacingTimeline = "Your Racing Timeline";

  // Event Details Screen
  static const String purchaseTicket = "Purchase Ticket";
  static const String fillFormText = "Please fill out this form";
  static const String insuranceName = "Insurance Name";
  static const String insuranceNumber = "Insurance Number";
  static const String age = "Are You 16+ Years Old?";
  static const String fill = "Fill The Form";
  static const String sellTicket = "Sell Ticket";
}

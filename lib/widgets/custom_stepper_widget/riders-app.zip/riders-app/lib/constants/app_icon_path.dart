class AppIconPath {
  AppIconPath._();

  static const String visibilityOnIcon = "assets/icons/visibility_on.svg";
  static const String visibilityOffIcon = "assets/icons/visibility_off.svg";

  // Bottom Nav Bar
  static const String homeIcon = "assets/icons/home_icon.svg";
  static const String productIcon = "assets/icons/product_icon.svg";
  static const String couponIcon = "assets/icons/coupon_icon.svg";
  static const String imageIcon = "assets/icons/image_icon.svg";
  static const String profileIcon = "assets/icons/profile_icon.svg";

  // Primary Appbar
  static const String notificationIcon = "assets/icons/notification_icon.svg";
  static const String cartIcon = "assets/icons/cart_icon.svg";
  static const String searchIcon = "assets/icons/search_icon.svg";

  // Product Screen
  static const String filterIcon = "assets/icons/filter_icon.svg";

  // Cart Screen
  static const String deleteIcon = "assets/icons/delete_icon.svg";

  // Notifications Screen
  static const String newRecordIcon = "assets/icons/new_record_icon.svg";
  static const String orderConfirmationIcon =
      "assets/icons/order_confirmation_icon.svg";
  static const String vehicleUpdateIcon =
      "assets/icons/vehicle_update_icon.svg";

  // Event Details Screen
  static const String groupIcon = "assets/icons/group_icon.svg";
}
